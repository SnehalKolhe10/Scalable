app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
